package com.test.calc;

import android.app.Activity;
import android.os.Bundle;
//import com.*;

public class Splash extends Activity {

	@Override
	protected void onCreate(Bundle TraviosLoveBacon) {
		// TODO Auto-generated method stub
		super.onCreate(TraviosLoveBacon);
		setContentView(R.layout.splash);
	}
	

}
